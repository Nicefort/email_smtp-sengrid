from django.http import JsonResponse
from django.views.decorators.csrf import csrf_exempt
import smtplib
import json
from sendgrid import SendGridAPIClient
from sendgrid.helpers.mail import Mail

from django.http import JsonResponse
from django.views.decorators.csrf import csrf_exempt
import smtplib
import json

from django.http import JsonResponse
from django.views.decorators.csrf import csrf_exempt
import smtplib
import json


@csrf_exempt
def send_email_smtp(request):
    if request.method == 'POST':
        #Charge les données envoyer par le frontend
        data = json.loads(request.body.decode('utf-8'))
        sender = data['sender']
        recipient = data['recipient']
        message = data['message']

        try:
            server = smtplib.SMTP('localhost', 1025)
            server.sendmail(sender, [recipient], message.encode('utf-8'))
            server.quit()
            return JsonResponse({'status': 'Email envoyé via SMTP'})
        except Exception as e:
            print(f"Error: {str(e)}")
            return JsonResponse({'status': f'Erreur : {str(e)}'})

def send_email_sendgrid(request):
    if request.method == 'POST':
        try:
            data = json.loads(request.body)
            print(f"Data received: {data}")

            sender = data['sender']
            recipient = data['recipient']
            message = data['message']
            print(f"Sending email from {sender} to {recipient} with message: {message}")

            sg = SendGridAPIClient('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')
            mail = Mail(
                from_email=sender,
                to_emails=recipient,
                subject='Message via SendGrid',
                plain_text_content=message
            )
            response = sg.send(mail)

            print(f"SendGrid response status: {response.status_code}")
            print(f"SendGrid response body: {response.body}")  # Afficher le corps de la réponse
            print(f"SendGrid response headers: {response.headers}")  # Afficher les en-têtes de la réponse

            if response.status_code == 202:
                return JsonResponse({'status': 'Email envoyé via SendGrid'})
            else:
                return JsonResponse({'status': f'Erreur SendGrid : {response.status_code}'})
        except Exception as e:
            print(f"Error: {str(e)}")
            return JsonResponse({'status': f'Erreur : {str(e)}'})
