from django.urls import path
from .views import send_email_smtp, send_email_sendgrid

urlpatterns = [
    path('send-email-smtp/', send_email_smtp, name='send_email_smtp'),
    path('send-email-sendgrid/', send_email_sendgrid, name='send_email_sendgrid'),
]

